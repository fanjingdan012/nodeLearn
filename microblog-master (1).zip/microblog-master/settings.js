module.exports = {
    cookieSecret: 'microblogyuanzm',
    db: 'blog',
    host: 'localhost'
};