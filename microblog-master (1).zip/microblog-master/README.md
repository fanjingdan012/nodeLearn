microblog
=========

《nodejs开发指南》微博实例express4.x版

> * 运行环境：  
        node >= v0.10.28  
        express >= 4.2.0
> * 运行命令   
        npm install  
        node app.js
