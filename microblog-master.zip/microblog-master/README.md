microblog
=========

simple microblog power by express4 and jade template

Start the server commmand:  NODE_ENV=production node cluster.js

启动服务器命令：NODE_ENV=production node cluster.js
