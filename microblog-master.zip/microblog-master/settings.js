module.exports = {
cookieSecret: 'microblogtony2014',
db: 'blog',
host: 'localhost',
};
